#ifndef CHAININGHASH_H
#define CHAININGHASH_H
#include<iostream>
#include<list>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;

int hashval(string key);
int hashval(int key);

template<typename Hashed>
class HashTable{
    private:
        int tablesize;
        list<Hashed> *table;
    public:
        HashTable(int x){
            tablesize = x;
            table = new list<Hashed>[tablesize];
        }
        bool insert(Hashed x);
        bool remove(Hashed x);
        bool contains(Hashed x);
        void print();
        int hash(Hashed x);
};

template<typename Hashed>
bool HashTable<Hashed> :: insert(Hashed x){
    int pos = hash(x);
    if( find(table[pos].begin(),table[pos].end(),x) != table[pos].end())
        return false;
    table[pos].push_front(x);
    return true;
}

template<typename Hashed>
bool HashTable<Hashed> :: remove(Hashed x){
    int pos = hash(x);
    typename list<int> :: iterator itr = find(table[pos].begin(),table[pos].end(),x);
    if(itr == table[pos].end())
        return false;
    table[pos].erase(itr);
    return true;

}

template<typename Hashed>
bool HashTable<Hashed> :: contains(Hashed x){
    int pos = hash(x);
    if( find(table[pos].begin(),table[pos].end(),x) != table[pos].end())
        return true;
    return false;
}

template<typename Hashed>
int HashTable<Hashed> :: hash(Hashed x){
    float k = (sqrt(5)-1)/2;
    int val = hashval(x);
    float num = k*val;
    float frac = num-int(num);
    val = floor(tablesize*frac);
    return val;
}
template<typename Hashed>
void HashTable<Hashed> :: print(){
    for(int i=0;i<tablesize;i++){
        cout<<i;
        list<int> :: iterator itr;
        for(itr = table[i].begin();itr != table[i].end();itr++){
            cout<<"-->"<<*itr;
        }
        cout<<endl;
    }
}

#endif