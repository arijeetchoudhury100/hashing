#ifndef BST_H
#define BST_H
#include<iostream>
using namespace std;

template<typename T>
class BinarySearchTree{

    public:
        BinarySearchTree(){
            root = NULL;
        }
        ~BinarySearchTree(){
            makeEmpty();
        }
        bool isEmpty(){
            if(root == NULL)
                return true;
            else 
                return false;
        }
        bool contains(T x){
            return contains(x,root);
        }
        void print(){
            if(isEmpty())
                cout<<"Empty tree";
            else
                print(root);
            cout<<endl;
        }
        void makeEmpty(){
            makeEmpty(root);
        }
        void insert(T x){
            insert(x,root);
        }
        void remove(T x){
            remove(x,root);
        }
    private:
        struct node{
            T element;
            node *left;
            node *right;

            node(T x,node* l,node* r){
                element = x;
                left = l;
                right = r;
            }
        };
        node *root;
        void insert(T x,node* & t){  //passed by reference so that root is changed
            if(t == NULL){
                t = new node(x,NULL,NULL);
            }
            else if(x<t->element)
                insert(x,t->left);
            else if(x>t->element)
                insert(x,t->right);
            else
                ;//duplicate element
        }
        void remove(T x,node* & t){
            if(t == NULL)
                return;
            if(x < t->element)
                remove(x,t->left);
            else if(x > t->element)
                remove(x,t->right);
            else if(t->left != NULL && t->right != NULL){   //two child nodes
                t->element = findMin(t->right)->element;
                remove(t->element,t->right);
            }
            else{   //one or zero child
                if(t->left == NULL)
                    t = t->right;
                else
                    t = t->left;
            }
        }
        node* findMin(node* t){
            if(t == NULL)
                return NULL;
            else if(t->left == NULL)
                return t;
            return findMin(t->left);
        }
        node* findMax(node* t){
            if(t == NULL)
                return NULL;
            else if(t->right == NULL)
                return t;
            return findMin(t->right);
        }
        bool contains(T x,node* t){
            if(t == NULL)
                return false;
            else if(x < t->element)
                return contains(x,t->left);
            else if(x > t->element)
                return contains(x,t->right);
            else    //element found
                return true;
        }
        void makeEmpty(node* & t){
            if(t!=NULL){
                makeEmpty(t->left);
                makeEmpty(t->right);
                delete t;
            }
            t=NULL;
        }
        void print(node *t){
            if(t){
                print(t->left);
                cout<<t->element<<" ";
                print(t->right);
            }
        }
};
#endif