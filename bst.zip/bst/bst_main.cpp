#include "bst.h"
#include<iostream>
using namespace std;
int main(){
    BinarySearchTree<int> b1;
    
    b1.insert(10);
    b1.insert(20);
    b1.insert(7);
    b1.insert(35);
    b1.insert(1);
    b1.insert(9);
    
    b1.print();

    b1.remove(20);
    b1.remove(10);

    b1.print();

    cout<<b1.contains(7)<<endl;
    cout<<b1.contains(20)<<endl;

    return 0;
}