#include<iostream>
#include<fstream>
#include<algorithm>
#include "linearprobing.h"
using namespace std;

int hashval(string key){
    int val=0;
    for(int i=0;i<key.length();i++){
        val += key[i];
    }
    return val;
}
int hashval(int key){
    return key;
}
int main(){
    HashTable<int> tab(100);
    ifstream file("input.txt");
    string word;
    while(file >> word){
        for(int i=0;i<word.length();i++)
            if(ispunct(word[i]))
                word.erase(word.find_first_of(word[i]));
        if(word.length()<10){
            int n = 10-word.length();
            word.append(n,'*');
        }
        if(word.length()>10){
            word = word.substr(0,10);
        }
        //cout<<word<<endl;
        int val = hashval(word);
        tab.insert(val);
    }
    tab.print();
    return 0;
}
